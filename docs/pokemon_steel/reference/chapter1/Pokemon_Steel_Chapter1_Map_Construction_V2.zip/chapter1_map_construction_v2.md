# Pokémon Steel — Chapter 1 Construction Freeze V2

## Design target
The supplied concept images are now the visual/topological target. The earlier schematic was too short and too polite:
players could stay on clean paths almost the whole time.

This version deliberately aims for the *Viridian Forest / Petalburg Woods feeling*:
long traversal, repeated mandatory grass, trainers spaced across the journey, false pockets, hidden rewards,
and return shortcuts that make the map feel larger than a straight corridor.

## Working Chapter 1 flow
**Homestead / Alumina → Southwoods → South Trail → Route 1 → Oakridge Town → Gym #1**

For this construction pass, the concept-image flow is treated as the current working progression.
No Route 2, Alloyridge construction, later cities, later gyms, or art-polish work belongs in this ticket.

---

# SOUTHWOODS
**36×60 = 2,160 semantic cells.**

That is intentionally about the same map footprint as the project copy of Petalburg Woods (~2,112 block cells),
but reshaped wider so the two northern entrances can coexist.

### Connections
- Homestead: north-west seam, x 3–9.
- Alumina Village: north-east seam, x 26–32.
- South Trail: south seam, x 16–20.

### Mandatory-route metrics
- Homestead → South Trail: **109 steps**
  with **35 tall-grass steps**.
- Alumina → South Trail: **110 steps**
  with **35 tall-grass steps**.

**Hard rule:** final Porymap layout may vary, but the shortest legal first-visit path should stay around 100 steps
and must force at least 20 encounter-grass tiles.

### Landmarks
1. Split Homestead / Alumina trailheads.
2. Logging-remnant side pockets.
3. Central safe clearing.
4. Zig-zag deep-forest section.
5. Mandatory deep-grass corridors.
6. Broad creek.
7. Main bridge.
8. Lower secret loops.
9. South Trail exit.

### Trainers
- Required: T2, T3, T5.
- Optional: T1, T4, T6.
- Working level band: roughly 4–7.
- Exact classes/species remain unfrozen.

### Rewards
Potion, Antidote, Poké Ball, and at least two hidden items.
One future Cut shortcut is allowed, but Cut is never required to finish Chapter 1.

---

# ROUTE 1
**36×72 = 2,592 semantic cells.**

### Connections
- North: South Trail.
- South: Oakridge Town.

### Mandatory-route metrics
- South Trail → Oakridge: **129 steps**
- Forced tall grass on shortest route: **37 tiles**

**Hard rule:** keep the final shortest route above ~120 movement steps if practical, with at least 20 forced grass tiles.
There must not be a clean, zero-encounter path to Oakridge.

### Route rhythm
safe path → grass → trainer → safe pocket → grass → trainer → mine/river landmark →
bridge → grass → trainer → exploration branch → grass → trainer → final grass → Oakridge

### Landmarks
1. North Route 1 sign.
2. Upper meadow / first grass field.
3. One-way ledge return shortcut.
4. Waterfall / river.
5. Camper pocket.
6. Blocked old mine.
7. Mandatory bridge.
8. Red-clay / industrial-remnant lower section.
9. Final approach field.
10. Oakridge exit.

### Trainers
Required: T1, T3, T5, T7, T8.
Optional: T2, T4, T6.

Suggested progression band:
- T1 5–6
- T3 6–7
- T5 7–8
- T7/T8 8–9

Exact teams are not part of this map ticket.

### Rewards
Potion, Poké Ball, Antidote, Oran patch, and at least two hidden items.
The blocked mine is a future-return landmark, not a Chapter 1 dungeon.

---

# CODEX / PORYMAP HANDOFF

The PNGs are human construction drawings. The CSVs are the semantic cell grids.

Codes:
- X impassable trees/cliff
- P path
- G tall grass
- W water
- B bridge
- C clearing
- R rock/red-clay scenery
- E connection seam
- L one-way ledge/shortcut lane
- M blocked mine/ruin

Implementation rules:
1. Use Emerald tiles as placeholders; do not chase final art.
2. Do not accidentally create a path around mandatory grass gates.
3. No HM is required on first traversal.
4. Cut/ledge features are optional return shortcuts only.
5. Validate collision, seams, trainer sight lines, and actual shortest path in Porymap/in-game.
6. Stop at Oakridge/Gym #1.

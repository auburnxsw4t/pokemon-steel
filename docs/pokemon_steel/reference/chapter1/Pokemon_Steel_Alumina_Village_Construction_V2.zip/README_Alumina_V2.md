# Alumina Village Construction V2

This replaces the first Alumina semantic draft only. It intentionally follows the nicer approved/reference composition rather than the earlier blockier construction map.

## What changed
- Larger 48×36 working footprint.
- Central fountain/civic green is the visual and navigation anchor.
- Lake/dock is pushed confidently into the northwest rather than treated as a side rectangle.
- Two north homes flank the north/south spine.
- School gets its own northeast yard/playground area.
- Chapel has its own west-side pocket.
- Mart + Center form a lower-central service pair.
- League Registration has a dedicated east/southeast civic parcel.
- West / south / east / north paths all visibly feed into the main road network.
- South Longleaf Hollow exit is a broad, obvious path.
- Route 1 road remains visible but reserved/non-bypassing during Chapter 1.

## Important implementation rule
Do not translate this as giant rectangles of identical metatiles. The grid defines *functional zones*. Within each zone, use Gen III edge/corner variants, shrubs, fence breaks, flower patches, and path shoulders to make the final Porymap map feel organic.

## Collision
Walkable by default: P, G, C, L, D, B, and only those R cells intentionally used as soil/garden walkspace.
Blocked by default: X, H, F, V, W, T unless the selected Emerald metatile has a specific walkable function.

## Codex priority
1. road/exits
2. building footprints + warps
3. central plaza
4. lake/dock collision
5. school yard
6. landscaping buffers
7. decoration

Do not redesign Family Home, League Registration interior, Homestead Ridge, Longleaf Hollow, Route 1, or later maps as part of this correction.
